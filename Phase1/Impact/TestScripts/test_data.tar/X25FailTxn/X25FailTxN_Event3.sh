#!/bin/sh
 

SERVER='AGG_P_1'
USER='root'
PASSWORD='mobilink2010'

#NODE='GJR9852'
#NODE='BEL5901'
#NODE='AAK6991__'
#NODE='10:14:IAS:0'
NODE='1:11:IAS:0'
#NODEALIAS=$NODE
EVENTTYPE='Network Alarm'
SEVERITY=4
TYPE=1
CLASS=2057
SUMMARY='X.25 Circuit Down OML1'
ADDTEXT='Synthetic Text Event '+$SUMMARY
ALERTGROUP='X25'
ALERTKEY=$SUMMARY
OMCEMS='somcsys2'
EVENTID='X25FailTxN_001'

IDENTIFIER=$NODE+$TYPE+'X25FailTxN1'+$ALERTGROUP+$ALERTKEY

#if [ $# -lt 1 ]; then
#
#        echo "Usage: insert_alarm_node_only.sh <Node> "
#        exit
#fi
#NODE=$1 ; shift
#/opt/netcool/omnibus/bin/nco_sql -server WATEENP -user root<<EOF
/opt/IBM/tivoli/netcool/omnibus/bin/nco_sql -server $SERVER -user $USER -passwd $PASSWORD<<EOF

insert into alerts.status (Identifier, Severity, Summary, Node, NodeAlias, Class, EventType, Type, AddText, Manager, OmcEms, AlertGroup, AlertKey, EventId ) values

('$IDENTIFIER', $SEVERITY, '$SUMMARY', '$NODE','$NODEALIAS', $CLASS, '$EVENTTYPE', $TYPE, '$ADDTEXT', '$MANAGER', '$OMCEMS', '$ALERTGROUP', '$ALERTKEY', '$EVENTID')

go

quit

EOF
