#!/bin/sh
 

SERVER='AGG_P_1'
USER='root'
PASSWORD='mobilink2010'
NODE='10:14:IAS:0'
CLASS=2057
OMCEMS='somcsys2'

MANAGER='Synthetic'
#NODE='GJR9852'
NODEALIAS=$NODE
EVENTTYPE='Communication Alarm'
SEVERITY=1
TYPE=2
#CLASS=8891
SUMMARY='Cell long time no access'
ADDTEXT='Synthetic Text Event '+$SUMMARY
#EVENTID='CellPer_001'
EVENTID=''
ALERTGROUP='CellPer'
ALERTKEY="Cell 1"



IDENTIFIER=$NODE+$TYPE+'BSS_ENV'+$ALERTGROUP+$ALERTKEY

#if [ $# -lt 1 ]; then
#
#        echo "Usage: insert_alarm_node_only.sh <Node> "
#        exit
#fi
#NODE=$1 ; shift
#/opt/netcool/omnibus/bin/nco_sql -server WATEENP -user root<<EOF
/opt/IBM/tivoli/netcool/omnibus/bin/nco_sql -server $SERVER -user $USER -passwd $PASSWORD<<EOF

insert into alerts.status (Identifier, Severity, Summary, Node, NodeAlias, Class, EventType, Type, AddText, EventId, Manager, AlertGroup, OmcEms, AlertKey ) values

('$IDENTIFIER', $SEVERITY, '$SUMMARY', '$NODE','$NODEALIAS', $CLASS, '$EVENTTYPE', $TYPE, '$ADDTEXT', '$EVENTID', '$MANAGER', '$ALERTGROUP', '$OMCEMS', '$ALERTKEY');

go

quit

EOF
